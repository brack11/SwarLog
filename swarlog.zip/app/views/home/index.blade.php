@extends(Config::get('syntara::views.master'))
@section('content')
	<div class="container">
		<h3>There is something here</h3>
	</div>
@stop