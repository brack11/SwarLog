<div class="marginBottom"></div>
<div class="row">
	<div class="col-xs-12">
		<div class="alert alert-success fade-in" style="display:none;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<strong>{{ trans('custom.success') }}</strong> {{ trans('custom.qso.saved') }}
		</div>
		<div class="module">
			
			<div class="module-body">
				<div class="form-group col-sm-4">
					{{ Form::button(trans('custom.'.Request::segment(1).'.left'), array('class'=>'btn btn-danger btn-block', 'id'=>(Request::segment(1) != 'logger') ? 'sendEqsl' : 'deleteQsos', 'style'=>'display:none;')) }}
				</div>
				@if (Request::segment(1) != 'logger')
				<div class="form-group col-sm-4">
					{{ Form::button(trans('custom.'.Request::segment(1).'.center'), array('class'=>'btn btn-warning btn-block', 'id'=>'requestQsl', 'style'=>'display:none;')) }}
				</div>
				@endif
				<div class="form-group col-sm-4 {{ (Request::segment(1) == 'logger') ? 'col-sm-offset-4' : ''}}">
					{{ Form::button(trans('custom.'.Request::segment(1).'.right'), array('class'=>'btn btn-info btn-block', 'id'=>(Request::segment(1) != 'logger') ? 'noEqsl' : 'refreshQsos', 'style'=>'display:none;')) }}
				</div>
				<table class="table table-hover table-bordered table-condensed">
					<thead>
						<tr>
							@if (Request::segment(1) == 'logger')
							<th></th>
							@endif	
							<th>{{ trans('custom.qso.call') }}</th>
							<th>{{ trans('custom.qso.rst') }}</th>	
							<th>{{ trans('custom.qso.mode') }}</th>	
							<th>{{ trans('custom.qso.date') }}/{{ trans('custom.qso.utc') }}</th>	
							<th>{{ trans('custom.table.qsl') }}</th>	
							<th>{{ trans('custom.qso.freq') }}</th>	
							<th>{{ trans('custom.qso.band') }}</th>	
							<th>{{ trans('custom.table.country') }}</th>	
							<th>{{ trans('custom.table.territory') }}</th>	
							@if (Request::segment(1) == 'logger')
							<th></th>	
							@endif	
							<th></th>	
						</tr>
					</thead>
					<tbody>
						@if (isset($qsos))
							@foreach ($qsos as $qso)
								<tr>
								@if (Request::segment(1) == 'logger')
									<td>
									@if ($qso->customization()->exists())
										<i onclick="popUp('{{ url('show/map') }}?lat={{ $qso->customization->lat }}&amp;lon={{ $qso->customization->lon }}');" class="glyphicon glyphicon-map-marker mapShower"></i>
									@elseif ($qso->prefixes()->exists())
										<i onclick="popUp('{{ url('show/map') }}?lat={{ $qso->prefixes->last()->lat }}&amp;lon={{ $qso->prefixes->last()->lon }}');" class="glyphicon glyphicon-map-marker mapShower"></i>
									@endif
									</td>
								@endif
									<td>{{ strtoupper($qso->call) }}</td>
									<td>{{ strtoupper($qso->rst) }}</td>
									<td>{{ isset($qso->mode->name) ? $qso->mode->name : '' }}</td>
									<td>{{ $qso->date }}</td>
									<td class="{{ ($qso->qsl_rcvd == 'Y')?'warning':'info' }}">{{ $qso->qsl_rcvd }}</td>
									<td>{{ $qso->frequency }}</td>
									<td>{{ $bands[$qso->band->id] }}</td>
									<td>{{ is_object($qso->prefixes->first()) ? $qso->prefixes->first()->territory : trans('custom.undefined') }}
									</td>
									<td>{{ is_object($qso->prefixes->last()) ? $qso->prefixes->last()->territory : trans('custom.undefined') }}
									</td>
								@if (Request::segment(1) == 'logger')
									<td>
										<i onclick="window.location.href = '{{ url('logger/'.$qso->id.'/edit') }}'" class="glyphicon glyphicon-pencil mapShower"></i>
									</td>
								@endif
									<td>
										{{ Form::checkbox('qid[]',$qso->id) }}
									</td>
								</tr>
							@endforeach
						@endif
					</tbody>
				</table>
				{{ $qsos->links() }}
			</div>
		</div>	
	</div>
</div>
