<?php

return array(

    /**
     * contact name
     */
    'contact' => 'SWARLog',

    /**
     * Admin mail
     * use for mails
     */
    'email' => 'www@swarl.org',

    /**
     * View for user activation email
     */
    'user-activation-view' => 'syntara::mail.user-activation',

    'user-activation-object' => 'Account activation'
);